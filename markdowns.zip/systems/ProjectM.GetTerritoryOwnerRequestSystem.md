---
title: ProjectM.GetTerritoryOwnerRequestSystem
nav_exclude: true
search_exclude: true
---

# ProjectM.GetTerritoryOwnerRequestSystem (Server)

### _EventQuery

- **All Components:**
  - [ProjectM.Network.FromCharacter [ReadOnly]](/components/FromCharacter){:target="_blank"}
  - [ProjectM.Network.GetTerritoryOwnerRequestEvent [ReadOnly]](/components/GetTerritoryOwnerRequestEvent){:target="_blank"}

### __query_832539417_0

- **All Components:**
  - [ProjectM.Network.FromCharacter [ReadOnly]](/components/FromCharacter){:target="_blank"}
  - [ProjectM.Network.GetTerritoryOwnerRequestEvent [ReadOnly]](/components/GetTerritoryOwnerRequestEvent){:target="_blank"}

