---
title: ProjectM.Gameplay.Systems.DestroyWhenDisabledSystem
nav_exclude: true
search_exclude: true
---

# ProjectM.Gameplay.Systems.DestroyWhenDisabledSystem (Server)

### __query_1216346856_0

- **All Components:**
  - [ProjectM.DestroyWhenDisabled [ReadOnly]](/components/DestroyWhenDisabled){:target="_blank"}
  - [Unity.Entities.Disabled [ReadOnly]](/components/Disabled){:target="_blank"}
- **None Components:**
  - [Unity.Entities.DestroyTag [ReadOnly]](/components/DestroyTag){:target="_blank"}

