---
title: ProjectM.DestroyBuffOnMoveSystem
nav_exclude: true
search_exclude: true
---

# ProjectM.DestroyBuffOnMoveSystem (Server)

### __query_922633302_0

- **All Components:**
  - [ProjectM.Buff [ReadOnly]](/components/Buff){:target="_blank"}
  - [ProjectM.DestroyBuffOnMove [ReadOnly]](/components/DestroyBuffOnMove){:target="_blank"}

