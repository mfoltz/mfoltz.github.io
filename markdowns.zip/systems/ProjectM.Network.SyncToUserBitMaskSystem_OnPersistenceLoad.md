---
title: ProjectM.Network.SyncToUserBitMaskSystem_OnPersistenceLoad
nav_exclude: true
search_exclude: true
---

# ProjectM.Network.SyncToUserBitMaskSystem_OnPersistenceLoad (Server)

### _Query

- **All Components:**
  - [ProjectM.Network.SyncToUserBuffer [Buffer] [ReadOnly]](/components/SyncToUserBuffer){:target="_blank"}
  - ProjectM.PersistenceV2+LoadedTag [ReadOnly]
- **None Components:**
  - [ProjectM.Network.SyncToUserBitMask [ReadOnly]](/components/SyncToUserBitMask){:target="_blank"}

