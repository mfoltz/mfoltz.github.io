---
title: ProjectM.SpawnTagDebugSystem
nav_exclude: true
search_exclude: true
---

# ProjectM.SpawnTagDebugSystem (Server)

### _QueryWaitingForSync

- **All Components:**
  - [ProjectM.DisabledWaitingForSync](/components/DisabledWaitingForSync){:target="_blank"}
  - [Unity.Entities.SpawnTag [ReadOnly]](/components/SpawnTag){:target="_blank"}
- **None Components:**
  - [Unity.Entities.Disabled [ReadOnly]](/components/Disabled){:target="_blank"}

### _QueryWaitingForTransform

- **All Components:**
  - [ProjectM.DisabledWaitingForTransform](/components/DisabledWaitingForTransform){:target="_blank"}
  - [Unity.Entities.SpawnTag](/components/SpawnTag){:target="_blank"}
- **None Components:**
  - [Unity.Entities.Disabled [ReadOnly]](/components/Disabled){:target="_blank"}

