---
title: ProjectM.JewelCraftingStopSystem
nav_exclude: true
search_exclude: true
---

# ProjectM.JewelCraftingStopSystem (Server)

### _EventQuery

- **All Components:**
  - [ProjectM.Network.FromCharacter [ReadOnly]](/components/FromCharacter){:target="_blank"}
  - [ProjectM.Network.StopCraftJewelEvent [ReadOnly]](/components/StopCraftJewelEvent){:target="_blank"}

### __query_1259428144_0

- **All Components:**
  - [ProjectM.Network.FromCharacter [ReadOnly]](/components/FromCharacter){:target="_blank"}
  - [ProjectM.Network.StopCraftJewelEvent [ReadOnly]](/components/StopCraftJewelEvent){:target="_blank"}

### __query_1259428144_1

- **All Components:**
  - ProjectM.Network.NetworkIdSystem+Singleton [ReadOnly]

