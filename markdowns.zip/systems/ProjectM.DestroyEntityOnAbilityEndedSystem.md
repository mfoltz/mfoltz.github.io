---
title: ProjectM.DestroyEntityOnAbilityEndedSystem
nav_exclude: true
search_exclude: true
---

# ProjectM.DestroyEntityOnAbilityEndedSystem (Server)

### __query_1381200222_0

- **All Components:**
  - [ProjectM.AbilityCastEndedEvent [ReadOnly]](/components/AbilityCastEndedEvent){:target="_blank"}

