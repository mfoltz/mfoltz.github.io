---
title: ProjectM.SetupSyncedServerDebugSettingsForWorld_SimulationSystemGroup
nav_exclude: true
search_exclude: true
---

# ProjectM.SetupSyncedServerDebugSettingsForWorld_SimulationSystemGroup (Server)

### __query_524302123_0

- **All Components:**
  - [ProjectM.SyncedServerDebugSettings [ReadOnly]](/components/SyncedServerDebugSettings){:target="_blank"}

