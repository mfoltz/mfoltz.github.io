---
title: ProjectM.RemoveJewelChangedSystem_Server
nav_exclude: true
search_exclude: true
---

# ProjectM.RemoveJewelChangedSystem_Server (Server)

### __query_1105055077_0

- **All Components:**
  - [ProjectM.JewelChanged [ReadOnly]](/components/JewelChanged){:target="_blank"}

### __query_1105055077_1

- **All Components:**
  - ProjectM.LegendaryItemChangedEvent [ReadOnly]

