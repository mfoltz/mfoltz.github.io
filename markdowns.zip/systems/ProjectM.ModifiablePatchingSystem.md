---
title: ProjectM.ModifiablePatchingSystem
nav_exclude: true
search_exclude: true
---

# ProjectM.ModifiablePatchingSystem (Server)

### __query_1313386287_0

- **All Components:**
  - [Stunlock.Core.PrefabLookupMap [ReadOnly]](/components/PrefabLookupMap){:target="_blank"}

### __query_1313386287_1

- **All Components:**
  - [ProjectM.ModificationsRegistry [ReadOnly]](/components/ModificationsRegistry){:target="_blank"}

