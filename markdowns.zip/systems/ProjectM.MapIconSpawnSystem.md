---
title: ProjectM.MapIconSpawnSystem
nav_exclude: true
search_exclude: true
---

# ProjectM.MapIconSpawnSystem (Server)

### __query_1050583545_0

- **All Components:**
  - [ProjectM.MapIconPosition](/components/MapIconPosition){:target="_blank"}
  - [Unity.Transforms.Translation [ReadOnly]](/components/Translation){:target="_blank"}
  - [Unity.Entities.SpawnTag [ReadOnly]](/components/SpawnTag){:target="_blank"}

