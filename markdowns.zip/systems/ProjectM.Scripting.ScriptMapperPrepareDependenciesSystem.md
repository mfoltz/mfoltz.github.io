---
title: ProjectM.Scripting.ScriptMapperPrepareDependenciesSystem
nav_exclude: true
search_exclude: true
---

# ProjectM.Scripting.ScriptMapperPrepareDependenciesSystem (Server)

### __query_884425773_0

- **All Components:**
  - [ProjectM.GameDataInitializedSingleton [ReadOnly]](/components/GameDataInitializedSingleton){:target="_blank"}

