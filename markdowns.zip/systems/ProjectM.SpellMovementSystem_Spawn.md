---
title: ProjectM.SpellMovementSystem_Spawn
nav_exclude: true
search_exclude: true
---

# ProjectM.SpellMovementSystem_Spawn (Server)

### __query_1901699851_0

- **All Components:**
  - [ProjectM.Age [ReadOnly]](/components/Age){:target="_blank"}
  - [ProjectM.LifeTime [ReadOnly]](/components/LifeTime){:target="_blank"}
  - [ProjectM.SpellMovement](/components/SpellMovement){:target="_blank"}
  - [Unity.Transforms.Rotation](/components/Rotation){:target="_blank"}
  - [Unity.Transforms.Translation](/components/Translation){:target="_blank"}
  - [Unity.Entities.SpawnTag [ReadOnly]](/components/SpawnTag){:target="_blank"}

