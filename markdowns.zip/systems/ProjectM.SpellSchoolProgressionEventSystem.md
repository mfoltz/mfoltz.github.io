---
title: ProjectM.SpellSchoolProgressionEventSystem
nav_exclude: true
search_exclude: true
---

# ProjectM.SpellSchoolProgressionEventSystem (Server)

### __query_1453776405_0

- **All Components:**
  - [ProjectM.MapZoneCollection [ReadOnly]](/components/MapZoneCollection){:target="_blank"}

### __query_1453776405_1

- **All Components:**
  - [ProjectM.RootPrefabCollection [ReadOnly]](/components/RootPrefabCollection){:target="_blank"}

## Invalid Queries

- _UnlockEventQuery
- _ResetEventQuery
- _UnlockPassiveEventQuery
- _SharePassiveEventQuery
- _ShareAllPassivesEventQuery
- _LearnPassiveEventQuery
- _LearnAllPassivesEventQuery
- _DebugUnlockAllPassivesEventQuery
- _DebugUnlockPassiveEventQuery
- _DebugUnlockPassiveInStationEventQuery
