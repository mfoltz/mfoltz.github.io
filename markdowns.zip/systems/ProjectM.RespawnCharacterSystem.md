---
title: ProjectM.RespawnCharacterSystem
nav_exclude: true
search_exclude: true
---

# ProjectM.RespawnCharacterSystem (Server)

### __query_1631932508_2

- **All Components:**
  - [ProjectM.RootPrefabCollection [ReadOnly]](/components/RootPrefabCollection){:target="_blank"}

### __query_1631932508_3

- **All Components:**
  - [ProjectM.ServerRootPrefabCollection [ReadOnly]](/components/ServerRootPrefabCollection){:target="_blank"}

### __query_1631932508_4

- **All Components:**
  - ProjectM.Network.NetworkIdSystem+Singleton [ReadOnly]

## Invalid Queries

- _Query
- _EventQuery
- __query_1631932508_0
- __query_1631932508_1
