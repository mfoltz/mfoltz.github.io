---
title: ProjectM.Gameplay.Systems.GetOwnerRotationOnSpawnSystem
nav_exclude: true
search_exclude: true
---

# ProjectM.Gameplay.Systems.GetOwnerRotationOnSpawnSystem (Server)

### __query_1724438999_0

- **All Components:**
  - [ProjectM.GetOwnerRotation [ReadOnly]](/components/GetOwnerRotation){:target="_blank"}
  - [Unity.Entities.SpawnTag [ReadOnly]](/components/SpawnTag){:target="_blank"}

