---
title: ProjectM.GarbageCollectArchetypeSystem
nav_exclude: true
search_exclude: true
---

# ProjectM.GarbageCollectArchetypeSystem (Server)

### __query_1722191443_0

- **All Components:**
  - [ProjectM.DisableUseFastQueries [ReadOnly]](/components/DisableUseFastQueries){:target="_blank"}

## Invalid Queries

- _SceneTagQuery
- _PrefabQuery
