---
title: ProjectM.ChangeKnockbackResistanceDuringCast_Shared
nav_exclude: true
search_exclude: true
---

# ProjectM.ChangeKnockbackResistanceDuringCast_Shared (Server)

### __query_1589524844_0

- **All Components:**
  - [ProjectM.AbilityCastStartedEvent [ReadOnly]](/components/AbilityCastStartedEvent){:target="_blank"}

### __query_1589524844_1

- **All Components:**
  - [ProjectM.AbilityCastEndedEvent [ReadOnly]](/components/AbilityCastEndedEvent){:target="_blank"}

