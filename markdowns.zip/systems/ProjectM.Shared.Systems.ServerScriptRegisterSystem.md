---
title: ProjectM.Shared.Systems.ServerScriptRegisterSystem
nav_exclude: true
search_exclude: true
---

# ProjectM.Shared.Systems.ServerScriptRegisterSystem (Server)

### _Query

- **All Components:**
  - [ProjectM.Scripting.InitializeGameplayScriptsEvent [ReadOnly]](/components/InitializeGameplayScriptsEvent){:target="_blank"}
  - [ProjectM.Scripting.HashedTypesBuffer [Buffer] [ReadOnly]](/components/HashedTypesBuffer){:target="_blank"}

### __query_1231292083_0

- **All Components:**
  - [ProjectM.Scripting.InitializeGameplayScriptsEvent [ReadOnly]](/components/InitializeGameplayScriptsEvent){:target="_blank"}
  - [ProjectM.Scripting.HashedTypesBuffer [Buffer] [ReadOnly]](/components/HashedTypesBuffer){:target="_blank"}

