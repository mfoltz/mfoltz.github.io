---
title: ProjectM.Gameplay.Systems.DoorSystem
nav_exclude: true
search_exclude: true
---

# ProjectM.Gameplay.Systems.DoorSystem (Server)

### _Query

- **All Components:**
  - [ProjectM.Door](/components/Door){:target="_blank"}

### __query_965102453_0

- **All Components:**
  - [ProjectM.Door](/components/Door){:target="_blank"}

### __query_965102453_3

- **All Components:**
  - [ProjectM.ServerTime [ReadOnly]](/components/ServerTime){:target="_blank"}

### __query_965102453_4

- **All Components:**
  - [ProjectM.ModificationsRegistry [ReadOnly]](/components/ModificationsRegistry){:target="_blank"}

## Invalid Queries

- __query_965102453_1
- __query_965102453_2
