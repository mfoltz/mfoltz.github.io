---
title: ProjectM.Gameplay.Systems.ArmorLevelSystem_Destroy
nav_exclude: true
search_exclude: true
---

# ProjectM.Gameplay.Systems.ArmorLevelSystem_Destroy (Server)

### __query_663986292_0

- **All Components:**
  - [ProjectM.Buff [ReadOnly]](/components/Buff){:target="_blank"}
  - [ProjectM.ArmorLevel](/components/ArmorLevel){:target="_blank"}
  - [Unity.Entities.DestroyTag [ReadOnly]](/components/DestroyTag){:target="_blank"}

