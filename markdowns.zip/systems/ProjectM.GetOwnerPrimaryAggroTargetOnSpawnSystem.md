---
title: ProjectM.GetOwnerPrimaryAggroTargetOnSpawnSystem
nav_exclude: true
search_exclude: true
---

# ProjectM.GetOwnerPrimaryAggroTargetOnSpawnSystem (Server)

### __query_392415901_0

- **All Components:**
  - [ProjectM.EntityOwner [ReadOnly]](/components/EntityOwner){:target="_blank"}
  - [ProjectM.GetOwnerPrimaryAggroTargetOnSpawn](/components/GetOwnerPrimaryAggroTargetOnSpawn){:target="_blank"}
  - [ProjectM.AggroBuffer [Buffer] [ReadOnly]](/components/AggroBuffer){:target="_blank"}
  - [ProjectM.AggroDamageHistoryBufferElement [Buffer] [ReadOnly]](/components/AggroDamageHistoryBufferElement){:target="_blank"}

