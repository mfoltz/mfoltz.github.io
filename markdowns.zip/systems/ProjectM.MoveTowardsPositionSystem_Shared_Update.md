---
title: ProjectM.MoveTowardsPositionSystem_Shared_Update
nav_exclude: true
search_exclude: true
---

# ProjectM.MoveTowardsPositionSystem_Shared_Update (Server)

### __query_356229735_0

- **All Components:**
  - [ProjectM.Buff [ReadOnly]](/components/Buff){:target="_blank"}
  - [ProjectM.MoveTowardsPositionBuff [ReadOnly]](/components/MoveTowardsPositionBuff){:target="_blank"}
  - [Unity.Transforms.Translation [ReadOnly]](/components/Translation){:target="_blank"}

