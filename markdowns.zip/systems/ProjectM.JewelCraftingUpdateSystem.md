---
title: ProjectM.JewelCraftingUpdateSystem
nav_exclude: true
search_exclude: true
---

# ProjectM.JewelCraftingUpdateSystem (Server)

### __query_1259428393_0

- **All Components:**
  - [ProjectM.JewelCraftingStation](/components/JewelCraftingStation){:target="_blank"}
  - [ProjectM.EditableTileModel [ReadOnly]](/components/EditableTileModel){:target="_blank"}
  - [ProjectM.CastleWorkstation [ReadOnly]](/components/CastleWorkstation){:target="_blank"}
  - [ProjectM.JewelCraftingProcessingRequiredItem [Buffer]](/components/JewelCraftingProcessingRequiredItem){:target="_blank"}
  - [ProjectM.WorkstationRecipesBuffer [Buffer] [ReadOnly]](/components/WorkstationRecipesBuffer){:target="_blank"}

